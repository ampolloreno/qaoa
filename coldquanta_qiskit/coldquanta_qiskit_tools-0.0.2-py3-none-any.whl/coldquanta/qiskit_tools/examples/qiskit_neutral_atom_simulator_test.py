from coldquanta.qiskit_tools.examples.test_tools import run_notebook
import os

def test_qiskit_neutral_atom_simulator_notebook():
    base_path = os.path.abspath(os.path.dirname(__file__))
    nb, errors = run_notebook(os.path.join(base_path, 'qiskit_neutral_atom_simulator.ipynb'))
    assert len(errors) == 0