from qiskit import QuantumRegister, QuantumCircuit, execute
from qiskit import Aer
import qiskit.ignis.verification.tomography as tomo
from qiskit.quantum_info import state_fidelity

from coldquanta.qiskit_tools.modeling.neutral_atom_noise_model import create_noise_model
from coldquanta.qiskit_tools.coldquanta_sim_backend import ColdQuantaSimBackend

#import matplotlib.pyplot as plt
import numpy as np
from scipy import optimize
import math
import pytest


def test_create_noise_model_defaults():
    noise_model = create_noise_model()

    circ = QuantumCircuit(10)
    circ.rx(q=0, theta=math.pi / 2)
    for i in range(9):
        circ.cz(i, i + 1)
        for j in range(10):
            if j != i and j != i + 1:
                circ.iden(j)
    circ.measure_all()

    neutral_atom = ColdQuantaSimBackend(rows=4, cols=4)
    neutral_atom_config = neutral_atom.configuration()
    coupling_map = neutral_atom_config.coupling_map

    simulator = Aer.get_backend('qasm_simulator')
    result_noise = execute(circ,
                           simulator,
                           noise_model=noise_model,
                           coupling_map=coupling_map,
                           optimization_level=0).result()


    counts = result_noise.get_counts()

    # Make sure there are extra noise states and not just 2 states
    assert len(counts.keys()) > 2

def fractional_error(correct, approximate):
    return abs(correct-approximate)/abs(correct)

@pytest.mark.parametrize('t1_decay_ratio', [0.05, 0.025, 0.01, 0.005])
def test_t1(t1_decay_ratio):
    num_trials = 4096

    max_depth = 4/t1_decay_ratio
    depths = list(np.linspace(10, max_depth, 10).astype(int))
    count_array = []

    t1 = 1.0 / t1_decay_ratio
    t2 = t1  # Make t2 error as small as possible
    noise_model = create_noise_model(t1_time_s=t1,
                                     t2_time_s=t2,
                                     single_qubit_gate_time_s=1.0,
                                     single_qubit_depolarizing_error=0.000001)

    neutral_atom = ColdQuantaSimBackend(rows=1, cols=2)
    neutral_atom_config = neutral_atom.configuration()
    coupling_map = neutral_atom_config.coupling_map
    simulator = Aer.get_backend('qasm_simulator')


    for id_depth in depths:


        circ = QuantumCircuit(1)
        circ.x(0)
        for i in range(id_depth):
            circ.iden(0)

        circ.measure_all()

        result_noise = execute(circ,
                               simulator,
                               noise_model=noise_model,
                               coupling_map=coupling_map,
                               optimization_level=0,
                               shots=num_trials).result()

        counts = result_noise.get_counts()

        count_array.append(counts)

    zero_one_ratio = [a['1']/num_trials for a in count_array]

    #plt.plot(depths, zero_one_ratio)

    params = optimize.curve_fit(lambda x,a,b,c: c + a*np.exp(-b*(x)), depths, zero_one_ratio, p0=(1,t1_decay_ratio, 0))
    print(params)

    x = np.array(depths)

    a = params[0][0]
    b = params[0][1]
    c = params[0][2]

    #y = c + a*np.exp(-b*(x))
    #plt.plot(x, y)
    #plt.show()

    frac_error = fractional_error(t1_decay_ratio, b)

    assert frac_error < 0.1


@pytest.mark.parametrize('t2_ratio', [0.05, 0.025, 0.01, 0.005])
def test_t2(t2_ratio):

    num_trials = 8000
    delays = np.linspace(0, 4/t2_ratio, 10)

    t2_time = 1.0/t2_ratio

    t1 = 1000000 # make t1 as small as possible
    t2 = t2_time
    noise_model = create_noise_model(t1_time_s=t1,
                                     t2_time_s=t2,
                                     single_qubit_gate_time_s=1.0,
                                     single_qubit_depolarizing_error=0.00000001)

    neutral_atom = ColdQuantaSimBackend(rows=1, cols=2)
    neutral_atom_config = neutral_atom.configuration()
    coupling_map = neutral_atom_config.coupling_map

    simulator = Aer.get_backend('qasm_simulator')


    count_array = []
    for delay in delays:


        circ = QuantumCircuit(1)

        circ.ry(q=0, theta=math.pi/2)

        #Gap
        for i in range(int(delay)):
            circ.iden(0)
        circ.ry(q=0, theta=math.pi/2)
        circ.measure_all()

        # neutral_atom.validate_circuit(circ)
        # Execute noise-free simulation and get counts
        result_noise = execute(circ,
                               simulator,
                               noise_model=noise_model,
                               coupling_map=coupling_map,
                               optimization_level=0,
                               shots=num_trials).result()

        counts = result_noise.get_counts()
        count_array.append(counts)


    ones_measure = []
    for state_count in count_array:
        number_ones = 0

        if '1' in state_count:
            number_ones = state_count['1']

        ones_measure.append(number_ones/num_trials)

    #plt.plot(delays, ones_measure)

    params = optimize.curve_fit(lambda x, a, b, c: c + a * np.exp(-b * (x)), delays, ones_measure, p0=(1, t2_ratio, 0))

    x = np.array(delays)
    a = params[0][0]
    b = params[0][1]
    c = params[0][2]

    #y = c + a * np.exp(-b * (x))
    #plt.plot(x, y)
    #plt.show()

    frac_error = fractional_error(b, t2_ratio)

    assert frac_error < 0.1


@pytest.mark.parametrize('depolarizing_error', [0.5, 0.025, 0.01, 0.005])
def test_depolarizing_error(depolarizing_error):


    num_trials = 4096

    t1 = 10000000 # No t1/t2 compared to gate time
    t2 = 10000000

    noise_model = create_noise_model(t1_time_s=t1,
                                     t2_time_s=t2,
                                     single_qubit_gate_time_s=1.0,
                                     single_qubit_depolarizing_error=depolarizing_error)


    neutral_atom = ColdQuantaSimBackend(rows=1, cols=2)
    neutral_atom_config = neutral_atom.configuration()
    coupling_map = neutral_atom_config.coupling_map

    simulator = Aer.get_backend('qasm_simulator')


    delays = np.linspace(0, 4/depolarizing_error, 20)

    count_array = []
    for delay in delays:

        circ = QuantumCircuit(1)
        circ.ry(q=0, theta=math.pi/2)
        #Let qubit evolve with noise
        for i in range(int(delay)):
            circ.iden(0)
        circ.ry(q=0, theta=math.pi/2)
        circ.measure_all()

        result_noise = execute(circ,
                               simulator,
                               noise_model=noise_model,
                               coupling_map=coupling_map,
                               optimization_level=0,
                               shots=num_trials).result()

        counts = result_noise.get_counts()
        count_array.append(counts)

    ones_measure = []
    for state_count in count_array:
        number_ones = 0

        if '1' in state_count:
            number_ones = state_count['1']

        ones_measure.append(number_ones/num_trials)

    #plt.plot(delays, ones_measure)

    params = optimize.curve_fit(lambda x, a, b, c: c + a * np.exp(-b * (x)), delays, ones_measure, p0=(1, depolarizing_error, 0))
    print(params)

    x = np.array(delays)

    a = params[0][0]
    b = params[0][1]
    c = params[0][2]
    #y = c + a * np.exp(-b * (x))
    #plt.plot(x, y)
    #plt.show()

    frac_error = fractional_error(b, depolarizing_error)

    assert frac_error < 0.1


@pytest.mark.parametrize('cz_fidelity', [
    0.7,
    0.8,
    0.9,
    0.95,
    0.999
])
def test_cz_fidelity(cz_fidelity):

    # https://github.com/Qiskit/qiskit-community-tutorials/blob/master/ignis/tomography-overview.ipynb
    # https://arxiv.org/pdf/1110.2998.pdf

    num_trials = 20000

    neutral_atom = ColdQuantaSimBackend(rows=1, cols=2)
    neutral_atom_config = neutral_atom.configuration()
    coupling_map = neutral_atom_config.coupling_map

    simulator = Aer.get_backend('qasm_simulator')

    noise_model = create_noise_model(t1_time_s=1000000, # Make t1/t2 errors small
                                     t2_time_s=1000000,
                                     single_qubit_gate_time_s=1,
                                     single_qubit_depolarizing_error=0.00000000000000001, # make depolarizing error small
                                     cz_fidelity=cz_fidelity)

    q = QuantumRegister(2)
    bell = QuantumCircuit(q)

    # prepare bell state ####
    # Hadamard
    bell.r(q=q[0], phi=math.pi/2, theta=math.pi/2)
    bell.r(q=q[0], phi=0.0, theta=math.pi)

    # CNOT ###
    # H on q1
    bell.r(q=q[1], phi=math.pi / 2, theta=math.pi / 2)
    bell.r(q=q[1], phi=0.0, theta=math.pi)

    # CZ
    bell.cz(q[0], q[1])

    # H on q1
    bell.r(q=q[1], phi=math.pi / 2, theta=math.pi / 2)
    bell.r(q=q[1], phi=0.0, theta=math.pi)

    qst_bell = tomo.state_tomography_circuits(bell, q)

    noise_result = execute(qst_bell,
                           simulator,
                           noise_model=noise_model,
                           coupling_map=coupling_map,
                           optimization_level=0,
                           shots=num_trials).result()

    statefit = tomo.StateTomographyFitter(noise_result, qst_bell)


    p, M, weights = statefit._fitter_data(True, 0.5)

    M_dg = np.conj(M).T
    linear_inversion_matrix = np.linalg.inv(M_dg @ M) @ M_dg
    rho_bell = linear_inversion_matrix @ p
    rho_bell = np.reshape(rho_bell, (4, 4))


    # Simulate the bell state without noise
    job2 = execute(bell, Aer.get_backend('statevector_simulator'))
    psi_bell = job2.result().get_statevector(bell)

    # Calculate fidelity between noiseless and noise based state vector result
    F_bell = state_fidelity(psi_bell, rho_bell)


    assert fractional_error(correct=cz_fidelity, approximate=F_bell) < 0.02

