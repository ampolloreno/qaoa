# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from qiskit.providers.models import BackendConfiguration, GateConfig

from coldquanta.qc_client_api.protos import qc_client_api_pb2

VALID_NEUTRAL_ATOM_OPERATIONS = ["id", "cz", "r", "rz", "measure", "barrier"]


def check_qiskit_operation_is_supported(operation_name):
    if operation_name not in set(VALID_NEUTRAL_ATOM_OPERATIONS):
        raise ValueError("Circuit operation {} has no equivalent in the neutral atom gateset {}".format(operation_name,
                                                                                                        VALID_NEUTRAL_ATOM_OPERATIONS))


def qpu_state_to_ibm_config(qpu_state, name):
    """

    :param qpu_state: coldquanta qpu state object
    :return: ibm backend configuration object
    """

    # Get single qubits
    single_qubits = []
    for qubit_data in qpu_state.gate_configuration.qubits:
        qubit_id = qubit_data.qubit_id
        single_qubits.append([qubit_id])

    # Get cz qubits
    gate_pairs = []
    for cz_connection in qpu_state.gate_configuration.cz_connections:
        qubit_a = cz_connection.qubit_a
        qubit_b = cz_connection.qubit_b
        gate_pairs.append([qubit_a, qubit_b])

    # https://arxiv.org/pdf/1707.03429.pdf
    id_gate = GateConfig(name='id',
                         parameters=[],
                         qasm_def='gate id q { U(0,0,0) q; }',
                         coupling_map=single_qubits)

    cz_gate = GateConfig(name='cz',
                         parameters=[],
                         qasm_def='gate cz q1,q2 { CZ q1,q2; }',
                         coupling_map=gate_pairs)

    r_gate = GateConfig(name="r",
                        parameters=["theta", "phi"],
                        qasm_def='gate r(theta, phi) q { R(theta, phi) q; }',
                        coupling_map=single_qubits)

    rz_gate = GateConfig(name="rz",
                         parameters=["phi"],
                         qasm_def='gate rz(phi) q { RZ(phi) q; }',
                         coupling_map=single_qubits)

    gate_config = [
        id_gate,
        cz_gate,
        r_gate,
        rz_gate
    ]

    config = BackendConfiguration(backend_name=name,
                                  backend_version="1.0.0",
                                  n_qubits=len(single_qubits),
                                  basis_gates=["id", "cz", "r", "rz"],
                                  gates=gate_config,
                                  local=False,
                                  simulator=False,
                                  conditional=False,
                                  open_pulse=False,
                                  memory=False,
                                  max_shots=qpu_state.max_shots,
                                  coupling_map=gate_pairs
                                  )

    return config


def qobj_exp_to_circuit(qobj_experiment):
    """

    :param qobj_experiment: qiskit QasmQobjExperiment object
    :return: coldquanta.common.protos.qc_client_api_pb2.Circuit object
    """
    qiskit_qasm_instructions = qobj_experiment.instructions

    new_gates = []

    for instruction in qiskit_qasm_instructions:

        check_qiskit_operation_is_supported(instruction.name)

        if instruction.name == 'r':
            qubit = instruction.qubits[0]
            theta = instruction.params[0]
            phi = instruction.params[1]

            new_gate = qc_client_api_pb2.Gate(r=qc_client_api_pb2.GateR(theta=theta, phi=phi, qubit=qubit))
            new_gates.append(new_gate)

        if instruction.name == 'cz':
            qubit_a = instruction.qubits[0]
            qubit_b = instruction.qubits[1]

            new_gate = qc_client_api_pb2.Gate(cz=qc_client_api_pb2.GateCZ(qubit_a=qubit_a, qubit_b=qubit_b))
            new_gates.append(new_gate)

        if instruction.name == 'rz':
            qubit = instruction.qubits[0]
            phi = instruction.params[0]

            new_gate = qc_client_api_pb2.Gate(rz=qc_client_api_pb2.GateRZ(qubit=qubit, phi=phi))
            new_gates.append(new_gate)

    new_circuit = qc_client_api_pb2.Circuit(gates=new_gates)
    return new_circuit


def qiskit_circuit_to_coldquanta_circuit(qiskit_quantum_circuit):
    """

    :param qiskit_quantum_circuit: qiskit QuantumCircuit object
    :return: coldquanta.common.protos.qc_client_api_pb2 protocol buffer object
    """
    circuit_operations = qiskit_quantum_circuit._data

    new_gates = []

    for circuit_op in circuit_operations:

        operation = circuit_op[0]
        operation_name = operation.name

        check_qiskit_operation_is_supported(operation_name)

        gate_qubits = []
        for qubit in circuit_op[1]:
            gate_qubits.append(qubit.index)

        gate_params = operation.params

        if operation_name == 'r':
            qubit = gate_qubits[0]
            theta = gate_params[0]
            phi = gate_params[1]

            new_gate = qc_client_api_pb2.Gate(r=qc_client_api_pb2.GateR(theta=theta, phi=phi, qubit=qubit))
            new_gates.append(new_gate)

        if operation_name == 'cz':
            qubit_a = gate_qubits[0]
            qubit_b = gate_qubits[1]

            new_gate = qc_client_api_pb2.Gate(cz=qc_client_api_pb2.GateCZ(qubit_a=qubit_a, qubit_b=qubit_b))
            new_gates.append(new_gate)

        if operation_name == 'rz':
            qubit = gate_qubits[0]
            phi = gate_params[0]

            new_gate = qc_client_api_pb2.Gate(rz=qc_client_api_pb2.GateRZ(qubit=qubit, phi=phi))
            new_gates.append(new_gate)

    new_circuit = qc_client_api_pb2.Circuit(gates=new_gates)
    return new_circuit
