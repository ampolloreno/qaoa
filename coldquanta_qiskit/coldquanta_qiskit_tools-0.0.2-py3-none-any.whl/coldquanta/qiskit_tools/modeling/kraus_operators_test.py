from coldquanta.qiskit_tools.modeling.kraus_operators import create_neutral_t1_t2_error_kraus, create_neutral_cz_error_kraus
import numpy as np
import pytest


def check_trace_preserving(kraus_operators):

    dimensions = kraus_operators[0].shape

    total = np.zeros(dimensions).astype(np.complex128)
    for kraus_operator in kraus_operators:
        mult = kraus_operator.conj().T * kraus_operator
        total += mult


    id_op = np.identity(dimensions[0]).astype(np.complex128)

    np.allclose(total, id_op)



@pytest.mark.parametrize('t1', [0.1, 0.001, 0.0001])
@pytest.mark.parametrize('t2', [0.1, 0.001, 0.0001])
@pytest.mark.parametrize('t', [0.0015, 0.00015, 0.000015])
def test_t1_t2_kraus(t1, t2, t):
    kraus_operators = create_neutral_t1_t2_error_kraus(t1=t1, t2=t2, t=t)
    assert len(kraus_operators) == 3
    for kraus_operator in kraus_operators:
        assert kraus_operator.shape == (2, 2)
    check_trace_preserving(kraus_operators)



@pytest.mark.parametrize('fidelity', [1.0, 0.99, 0.7, 0.2, 0.1, 0.001, 0])
def test_cz_kraus(fidelity):
    kraus_operators = create_neutral_cz_error_kraus(fidelity=fidelity)
    assert len(kraus_operators) == 8
    for kraus_operator in kraus_operators:
        assert kraus_operator.shape == (4, 4)
    check_trace_preserving(kraus_operators)



