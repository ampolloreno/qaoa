# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math

class StateVector():
    def __init__(self, number_qubits):
        """
        Efficient state vector storage.
        This provides a veiw layer over a byte array.
        :param number_qubits:
        """
        self.number_qubits = number_qubits
        self._number_bytes = math.ceil(self.number_qubits / 8)
        self._byte_array = bytearray([0] * self._number_bytes)

    def set_qubit(self, qubit, value):
        byte_array_index = qubit // 8
        bit_position = qubit % 8

        current_value = self._byte_array[byte_array_index]

        new_value = self._set_bit(current_value, bit_position, int(value))

        self._byte_array[byte_array_index] = new_value

    def get_qubit(self, qubit):
        byte_array_index = qubit // 8
        bit_position = qubit % 8
        current_value = self._byte_array[byte_array_index]
        return self._get_bit(current_value, bit_position)

    def _get_bit(self, number, position):
        mask = 1 << position
        bit = (number & mask) != 0
        return int(bit)

    def _set_bit(self, number, position, value):
        mask = 1 << position
        new_value = (number & ~mask) | ((value << position) & mask)

        return new_value

    def get_bytes(self):
        return bytes(self._byte_array)

    def set_bytes(self, byte_array):
        if len(byte_array) != self._number_bytes:
            raise ValueError(
                "State vector with {} bits should have a byte array of length {} but bytes sent in have length {}".format(
                    self.number_qubits, self._number_bytes, len(byte_array)))

        self._byte_array = byte_array

    def get_array(self):
        state = []
        for i in range(self.number_qubits):
            qubit_state = self.get_qubit(i)
            state.append(qubit_state)
        return state

    def get_string(self):
        state = self.get_array()
        return ''.join([str(bit) for bit in state])
