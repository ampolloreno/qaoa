# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from qiskit.providers import BaseBackend, BaseJob, JobStatus
from qiskit.providers.jobstatus import JOB_FINAL_STATES
from qiskit.providers.models import (BackendStatus, BackendProperties,
                                     BackendConfiguration)

from coldquanta.qc_client_api.protos import qc_client_api_pb2
from coldquanta.qc_client_api.common.state_vector import StateVector
from coldquanta.qiskit_tools.qiskit_adapter_utils import qpu_state_to_ibm_config, qobj_exp_to_circuit

import time


class ColdQuantaJobResult():
    def __init__(self, counts_dictionary):
        self.counts_dictionary = counts_dictionary

    def get_counts(self):
        return self.counts_dictionary


class ColdQuantaJob(BaseJob):
    """
    Container to keep track of job after submission
    """

    def __init__(self, *, backend, job_id):
        self._backend = backend
        self._job_id = job_id
        BaseJob.__init__(self, self._backend, self._job_id)

    # Required of base
    def submit(self):
        """Submit the job to the backend for execution."""
        raise NotImplementedError(
            "Not currently supported, this job container is expected to exist after the job is submitted")

    def _qc_result_to_qiskit_result(self, job_output):
        # Get state counts
        state_counts = job_output.state_counts

        result_counts_dictionary = dict()
        for state_count in state_counts:
            state_vector_message = state_count.state_vector

            state_vector_bytes = state_vector_message.byte_array
            state_vector_number_bits = state_vector_message.bits

            count = state_count.count

            state_vector = StateVector(state_vector_number_bits)
            state_vector.set_bytes(state_vector_bytes)

            state_string = state_vector.get_string()

            result_counts_dictionary[state_string] = count

        # TODO -> package state counts into a Result object so qiskit works
        return ColdQuantaJobResult(counts_dictionary=result_counts_dictionary)

    def _delay(self):
        time.sleep(1)

    # Required of base
    def result(self):
        """Return the results of the job."""
        self._status = None
        while self._status not in JOB_FINAL_STATES:
            self._delay()
            self._status = self.status()

        api_qpu_job = self._backend.cold_quanta_api.get_job(job_id=self._job_id)

        # Get state counts
        qiskit_result = self._qc_result_to_qiskit_result(api_qpu_job.output)

        self._result = qiskit_result

        return self._result

    # Required of base
    def cancel(self):
        """Attempt to cancel the job."""
        raise NotImplementedError("Cancel is not yet supported")

    # Required of base
    def status(self):
        """Return the status of the job, among the values of ``JobStatus``."""
        api_job = self._backend.cold_quanta_api.get_job(job_id=self._job_id)

        # Map coldquanta status to ibm status
        qc_job_status = api_job.status
        cq_status = qc_client_api_pb2.QPUJob.Status
        lookup_table = {
            cq_status.PENDING: JobStatus.QUEUED,
            cq_status.RUNNING: JobStatus.RUNNING,
            cq_status.COMPLETE: JobStatus.DONE,
            cq_status.FAILED: JobStatus.ERROR,
            cq_status.CANCELLED: JobStatus.CANCELLED
        }

        qiskit_status = lookup_table[qc_job_status]

        return qiskit_status


class ColdQuantaBackend(BaseBackend):

    def __init__(self, *, cq_api, qpu_id):
        self._qpu_id = qpu_id
        self.cold_quanta_api = cq_api
        self._configuration = self.get_configuration()
        super().__init__(provider=None, configuration=self._configuration)

    def run(self, qobj):
        """Run a Qobj on the the backend.

        Args:instruction
            qobj (Qobj): the Qobj to be executed.
        """

        # Translate the IBM qobj to a protocol buffer
        api_circuit = qobj_exp_to_circuit(qobj.experiments[0])
        number_shots = qobj.config.shots

        api_job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id=self._qpu_id),
                                                              circuit=api_circuit,
                                                              shots=number_shots)

        # Get the most recent qpu state right before job submission
        this_qpu = self._get_qpu()
        this_qpu_state = this_qpu.qpu_state

        # Submit job using the coldquanta API
        job_id = self.cold_quanta_api.submit_job(job_input_message=api_job_input_message,
                                                 qpu_state_message=this_qpu_state)

        new_job = ColdQuantaJob(backend=self, job_id=job_id)

        return new_job

    def _get_qpu(self):
        qpu_array = self.cold_quanta_api.list_qpus()
        qpu_list = qpu_array.qpus

        matching_qpus = list(filter(lambda q: q.id == self._qpu_id, qpu_list))

        if len(matching_qpus) == 0:
            raise ValueError("qpu with id {} was not found".format(self._qpu_id))

        this_qpu = matching_qpus[0]

        return this_qpu

    def get_configuration(self):
        this_qpu = self._get_qpu()
        qpu_state = this_qpu.qpu_state
        qpu_name = this_qpu.name
        return qpu_state_to_ibm_config(qpu_state, name=this_qpu.name)

    def configuration(self):
        """Return the backend configuration.

        Returns:
            BackendConfiguration: the configuration for the backend.
        """

        # This may be called frequently, use attribute instead requesting
        # the configuration on demand from the coldquanta API

        return self._configuration

    def properties(self):
        """Return the backend properties.

        Returns:
            BackendProperties: the configuration for the backend. If the backend
            does not support properties, it returns ``None``.
        """
        return None

    def provider(self):
        """Return the backend Provider.

        Returns:
            BaseProvider: the Provider responsible for the backend.
        """
        return self._provider

    def status(self):
        """Return the backend status.

        Returns:
            BackendStatus: the status of the backend.
        """
        # qpu_state = self.cold_quanta_api.QPUList(self._qpu_id)

        qpu_array = self.cold_quanta_api.list_qpus()
        qpu_list = qpu_array.qpus

        matching_qpus = list(filter(lambda q: q.id == self._qpu_id, qpu_list))

        if len(matching_qpus) == 0:
            raise ValueError("qpu with id {} was not found".format(self._qpu_id))

        this_qpu = matching_qpus[0]

        qpu_operational = this_qpu.status == qc_client_api_pb2.QPUStatus.ONLINE
        qpu_name = this_qpu.name

        return BackendStatus(backend_name=qpu_name,
                             backend_version="1.0.0",
                             operational=qpu_operational,
                             pending_jobs=0,
                             status_msg='')

    def name(self):
        """Return the backend name.

        Returns:
            str: the name of the backend.
        """
        return self._configuration.backend_name
