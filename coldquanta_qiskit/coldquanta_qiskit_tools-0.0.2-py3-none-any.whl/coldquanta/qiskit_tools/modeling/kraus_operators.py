# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
import cmath

pauli_I = np.array([[1, 0],
                        [0, 1]]).astype(np.complex128)
pauli_X = np.array([[0, 1],
                    [1, 0]]).astype(np.complex128)
pauli_Y = np.array([[0, -1j],
                    [1j, 0]]).astype(np.complex128)
pauli_Z = np.array([[1, 0],
                    [0, -1]]).astype(np.complex128)

def create_neutral_t1_t2_error_kraus(*,t1, t2, t):
    """
    time unit does not matter as long as each one is the same unit.
    dimensions cancel

    :param t1: float t1 time
    :param t2: float t2 time
    :param t: float wait time
    :return: array of 2d arrays of kraus matrices
    """

    # page 82 qip
    t_phi = (2.0*t1*t2)/(2.0*t1 - t2)
    a = 1.0 - cmath.exp(-t/t1)
    b = cmath.exp(-t/t1)*(1.0 - cmath.exp((-2.0*t)/t_phi) )

    A1_term = cmath.sqrt(1 - a - b)

    A1 = ((1.0 + A1_term)/2.0)*pauli_I + ((1 - A1_term)/2)*pauli_Z
    A2 = (cmath.sqrt(a)/2)*pauli_X + ((1.0j*cmath.sqrt(a)) / 2)*pauli_Y
    A3 = (cmath.sqrt(b)/2)*pauli_I - (np.conj(cmath.sqrt(b))/2)*pauli_Z

    return [A1, A2, A3]



def create_neutral_cz_error_kraus(*, fidelity):
    # 1 - F = (2/5)a + (3/20)b^2

    infidelity = 1.0 - fidelity

    half_infidelity = infidelity/2.0

    a = (5.0/2.0)*half_infidelity
    b = cmath.sqrt((20.0/3.0)*half_infidelity)
    phi = cmath.pi/4

    def modulus(complex):
        (r, phi) = cmath.polar(complex)
        return r

    # Calculate the coefficients
    c1 = (1 + 2*cmath.sqrt(1-a) + cmath.exp(1j*b)) / 4.0

    c2 = (1 - cmath.exp(1j*b)) / 4.0
    c3 = c2

    c4 = (cmath.sqrt(a)*cmath.sin(phi)) / 2.0
    c5 = c4

    c6 = (cmath.sqrt(a)*cmath.cos(phi)) / 2.0
    c7 = c6

    c8 = (1 - 2*cmath.sqrt(1-a) + cmath.exp(1j*b)) / 4.0


    coeffs = [c1, c2, c3, c4, c5, c6, c7, c8]

    # Calculate the matrices
    A1 = np.kron(pauli_I, pauli_I)
    A2 = np.kron(pauli_Z, pauli_I)
    A3 = np.kron(pauli_I, pauli_Z)
    A4 = np.kron(pauli_X, pauli_X)
    A5 = np.kron(pauli_Y, pauli_Y)
    A6 = np.kron(pauli_X, pauli_Y)
    A7 = np.kron(pauli_Y, pauli_X)
    A8 = np.kron(pauli_Z, pauli_Z)

    terms = [A1, A2, A3, A4, A5, A6, A7, A8]


    kraus_operators = []

    for i in range(8):
        kraus_operator = coeffs[i]*terms[i]
        kraus_operators.append(kraus_operator)

    return kraus_operators