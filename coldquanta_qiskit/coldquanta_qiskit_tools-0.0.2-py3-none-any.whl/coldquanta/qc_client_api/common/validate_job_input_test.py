# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qc_client_api.common.validate_job_input import is_job_input_valid
from coldquanta.qc_client_api.protos import qc_client_api_pb2
import time


def mock_job_input(qpu_id):
    gates = []
    gates.append(qc_client_api_pb2.Gate(id=qc_client_api_pb2.GateID(qubit=0)))
    gates.append(qc_client_api_pb2.Gate(cz=qc_client_api_pb2.GateCZ(qubit_a=0, qubit_b=1)))
    gates.append(qc_client_api_pb2.Gate(r=qc_client_api_pb2.GateR(qubit=1, theta=0.5, phi=0.5)))
    gates.append(qc_client_api_pb2.Gate(gr=qc_client_api_pb2.GateGR(theta=0.5, phi=0.5)))

    circuit_message = qc_client_api_pb2.Circuit(gates=gates)

    job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id=qpu_id),
                                                      circuit=circuit_message, shots=200)

    return job_input_message


def mock_qpu_state():
    qubits = [qc_client_api_pb2.QubitData(qubit_id=0),
              qc_client_api_pb2.QubitData(qubit_id=1)]
    cz_connections = [qc_client_api_pb2.CZConnection(qubit_a=0, qubit_b=1)]

    gate_configuration = qc_client_api_pb2.GateConfiguration(qubits=qubits, cz_connections=cz_connections)

    qpu_state = qc_client_api_pb2.QPUState(gate_configuration=gate_configuration, max_shots=100)

    return qpu_state


def test_job_input_valid_valid():
    qpu_state = mock_qpu_state()
    job_input = mock_job_input(qpu_id="asdfasdf")

    is_valid, message = is_job_input_valid(job_input=job_input, qpu_state=qpu_state)

    assert is_valid == True
    assert message == ''


def test_job_input_valid_validation_speed():
    number_qubits = 100
    qubits = []
    for i in range(number_qubits):
        qubits.append(qc_client_api_pb2.QubitData(qubit_id=i))

    # Create worst case all pairs connectivity
    cz_connections = []
    for i in range(number_qubits):
        for j in range(number_qubits):
            cz_connections.append(qc_client_api_pb2.CZConnection(qubit_a=i, qubit_b=j))

    gate_configuration = qc_client_api_pb2.GateConfiguration(qubits=qubits, cz_connections=cz_connections)
    qpu_state = qc_client_api_pb2.QPUState(gate_configuration=gate_configuration, max_shots=100)

    # Circuit with gate across 0 and 1
    gates = []
    for i in range(50):
        gates.append(qc_client_api_pb2.Gate(cz=qc_client_api_pb2.GateCZ(qubit_a=i, qubit_b=i + 1)))
    for i in range(15):
        gates.append(qc_client_api_pb2.Gate(id=qc_client_api_pb2.GateID(qubit=i)))
        gates.append(qc_client_api_pb2.Gate(r=qc_client_api_pb2.GateR(qubit=i, theta=0.5, phi=0.5)))
        gates.append(qc_client_api_pb2.Gate(gr=qc_client_api_pb2.GateGR(theta=0.5, phi=0.5)))

    circuit_message = qc_client_api_pb2.Circuit(gates=gates)
    job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id="some_qpu"),
                                                      circuit=circuit_message,
                                                      shots=200)

    # Test

    times = []
    for i in range(10):
        start = time.time()
        is_valid, message = is_job_input_valid(job_input=job_input_message, qpu_state=qpu_state)
        end = time.time()
        delta = end - start
        times.append(delta)
        assert is_valid == True
        assert message == ""

    average_time = sum(times) / len(times)
    assert average_time < 0.1


def test_job_input_valid_wrong_connectivity():
    # Circuit with gate across 0 and 1
    gates = []
    gates.append(qc_client_api_pb2.Gate(cz=qc_client_api_pb2.GateCZ(qubit_a=0, qubit_b=1)))
    circuit_message = qc_client_api_pb2.Circuit(gates=gates)
    job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id="some_qpu"),
                                                      circuit=circuit_message, shots=200)

    # QPU state with connectivity between 1 and 2
    qubits = [qc_client_api_pb2.QubitData(qubit_id=0),
              qc_client_api_pb2.QubitData(qubit_id=1),
              qc_client_api_pb2.QubitData(qubit_id=2)]
    cz_connections = [qc_client_api_pb2.CZConnection(qubit_a=1, qubit_b=2)]
    gate_configuration = qc_client_api_pb2.GateConfiguration(qubits=qubits, cz_connections=cz_connections)
    qpu_state = qc_client_api_pb2.QPUState(gate_configuration=gate_configuration, max_shots=100)

    # Test
    is_valid, message = is_job_input_valid(job_input=job_input_message, qpu_state=qpu_state)

    assert is_valid == False
    assert message == "CZ gate between qubits 0 and 1 is not possible"


def test_job_input_valid_too_few_gates():
    # Circuit with not gates
    gates = []
    circuit_message = qc_client_api_pb2.Circuit(gates=gates)
    job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id="some_qpu"),
                                                      circuit=circuit_message, shots=200)

    qpu_state = mock_qpu_state()

    # Test
    is_valid, message = is_job_input_valid(job_input=job_input_message, qpu_state=qpu_state)

    assert is_valid == False
    assert message == "Circuit has no gates"


def test_job_input_valid_too_many_gates():
    gates = []
    for i in range(101):
        gates.append(qc_client_api_pb2.Gate(cz=qc_client_api_pb2.GateCZ(qubit_a=0, qubit_b=1)))
    circuit_message = qc_client_api_pb2.Circuit(gates=gates)
    job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id="some_qpu"),
                                                      circuit=circuit_message, shots=200)

    qpu_state = mock_qpu_state()

    # Test
    is_valid, message = is_job_input_valid(job_input=job_input_message, qpu_state=qpu_state)

    assert is_valid == False
    assert message == "Circuit depth cannot exceed 100"


def test_job_input_qubit_does_not_exist_r():
    gates = []

    gates.append(qc_client_api_pb2.Gate(r=qc_client_api_pb2.GateR(qubit=2, theta=0.0, phi=0.0)))

    circuit_message = qc_client_api_pb2.Circuit(gates=gates)
    job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id="some_qpu"),
                                                      circuit=circuit_message, shots=200)

    qpu_state = mock_qpu_state()

    # Test
    is_valid, message = is_job_input_valid(job_input=job_input_message, qpu_state=qpu_state)

    assert is_valid == False
    assert message == "Qubit 2 does not exist on physical hardware. Cannot perform gate r"


def test_job_input_qubit_does_not_exist_rz():
    gates = []

    gates.append(qc_client_api_pb2.Gate(rz=qc_client_api_pb2.GateRZ(qubit=2, phi=0.0)))

    circuit_message = qc_client_api_pb2.Circuit(gates=gates)
    job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id="some_qpu"),
                                                      circuit=circuit_message, shots=200)

    qpu_state = mock_qpu_state()

    # Test
    is_valid, message = is_job_input_valid(job_input=job_input_message, qpu_state=qpu_state)

    assert is_valid == False
    assert message == "Qubit 2 does not exist on physical hardware. Cannot perform gate rz"


def test_job_input_qubit_does_not_exist_id():
    gates = []

    gates.append(qc_client_api_pb2.Gate(id=qc_client_api_pb2.GateID(qubit=2)))

    circuit_message = qc_client_api_pb2.Circuit(gates=gates)
    job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id="some_qpu"),
                                                      circuit=circuit_message, shots=200)

    qpu_state = mock_qpu_state()

    # Test
    is_valid, message = is_job_input_valid(job_input=job_input_message, qpu_state=qpu_state)

    assert is_valid == False
    assert message == "Qubit 2 does not exist on physical hardware. Cannot perform gate id"
