# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import requests
from requests.models import PreparedRequest
import os
import hashlib
import base64
import json

OKTA_API_BASE_URL = "https://dev-528090.okta.com/oauth2/default/v1"
OKTA_CLIENT_ID = "0oa2cwiq69NG0o022357"
OKTA_REDIRECT_URL = "http://localhost:8080"


class OktaAPI():
    """
    Handle interactions with the Okta API
    """

    def __init__(self, base_url=OKTA_API_BASE_URL, client_id=OKTA_CLIENT_ID):
        self.base_url = base_url
        self.client_id = client_id

    def get_new_credentials(self, temporary_access_code, verifier):
        """

        :param temporary_access_code: string temporary code to use in exchange for a token
        :param verifier:
        :return:
        """
        url = self.base_url + "/token"

        headers = {
            "accept": "application/json",
            "cache-control": "no-cache",
            "content-type": "application/x-www-form-urlencoded"
        }

        form_parameters = {
            "grant_type": "authorization_code",
            "client_id": self.client_id,
            "redirect_uri": OKTA_REDIRECT_URL,
            "code": temporary_access_code,
            "code_verifier": verifier
        }

        response = requests.post(url, headers=headers, data=form_parameters, allow_redirects=False)

        response.raise_for_status()

        # https://developer.okta.com/docs/reference/api/oidc/#response-properties-2
        token_json = response.json()
        access_token = token_json["access_token"]
        refresh_token = token_json["refresh_token"]

        return {
            "access_token": access_token,
            "refresh_token": refresh_token
        }

    def refresh_token(self, refresh_token):
        """

        :param refresh_token: string refresh token
        :return: dictionary of {"access_token": <new_access_token>, "refresh_token": <new_refresh_token>}
        """
        url = self.base_url + "/token"

        headers = {
            "accept": "application/json",
            "cache-control": "no-cache",
            "content-type": "application/x-www-form-urlencoded"
        }

        form_parameters = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": self.client_id,
        }

        # https://developer.okta.com/docs/reference/api/oidc/#response-properties-2
        response = requests.post(url, headers=headers, data=form_parameters, allow_redirects=False)

        response.raise_for_status()
        token_json = response.json()
        access_token = token_json["access_token"]
        refresh_token = token_json["refresh_token"]

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
        }

    def get_new_service_credentials(self, client_secret):
        """

        :param client_secret: string
        :return: access_token: string
        """
        url = self.base_url + "/token"

        concat_secret = self.client_id + ":" + client_secret

        basic_digest = base64.b64encode(bytes(concat_secret, 'utf-8')).decode("utf-8")

        auth_header = "Basic " + basic_digest

        headers = {
            "accept": "application/json",
            "cache-control": "no-cache",
            "content-type": "application/x-www-form-urlencoded",
            "authorization": auth_header
        }

        form_parameters = {
            "grant_type": "client_credentials",
            "scope": "machine"
        }

        response = requests.post(url, headers=headers, data=form_parameters, allow_redirects=False)

        response.raise_for_status()

        # https://developer.okta.com/docs/reference/api/oidc/#response-properties-2
        token_json = response.json()
        access_token = token_json["access_token"]

        return access_token

    def get_public_key(self):

        url = self.base_url + "/keys"
        resp = requests.get(url, allow_redirects=False)

        if resp.status_code != 200:
            raise ValueError("Could not retrieve public key")

        json_dictionary = resp.json()
        key_array = json_dictionary["keys"]

        if len(key_array) != 1:
            raise ValueError(
                "Only single public key authication is supported at this time. Number of public keys from okta: {}".format(
                    len(key_array)))

        first_key = key_array[0]
        key_string = json.dumps(first_key)

        return key_string


class AuthTools():
    """
    Helper methods for authentication
    """

    def __init__(self):
        self.client_id = OKTA_CLIENT_ID
        self.base_url = OKTA_API_BASE_URL
        self.redirect_url = OKTA_REDIRECT_URL

        self.okta_api = OktaAPI()

    def _url_safe(self, input):
        """
        :param input:
        :return:
        """
        return base64.urlsafe_b64encode(input).rstrip(b'=')

    def _generate_verifier(self, n_bytes):
        return self._url_safe(os.urandom(n_bytes))

    def _generate_challenge(self, verifier):
        digest = hashlib.sha256(verifier).digest()
        return self._url_safe(digest)

    def _create_url(self, code_challenge):
        req = PreparedRequest()
        url = self.base_url + "/authorize"
        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "scope": "offline_access",
            "redirect_uri": self.redirect_url,
            "state": "state-296bc9a0-a2a2-4a57-be1a-d0e2fd9bb601",
            "code_challenge_method": "S256",
            "code_challenge": code_challenge
        }

        req.prepare_url(url, params)

        return req.url

    def get_auth_url(self, challenge):
        browser_url = self._create_url(challenge)
        return browser_url
