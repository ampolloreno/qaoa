# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qc_client_api.common.state_vector import StateVector
import pytest


@pytest.mark.parametrize("num_qubits,num_bytes", [
    (1, 1),
    (2, 1),
    (8, 1),
    (9, 2),
    (16, 2),
    (17, 3),
    (64, 8),
    (65, 9)
])
def test_constructor(num_qubits, num_bytes):
    sv = StateVector(num_qubits)
    assert sv.number_qubits == num_qubits
    assert sv._number_bytes == num_bytes
    assert sv._byte_array == bytearray([0] * num_bytes)


@pytest.mark.parametrize("bit_pos,expected_byte_array", [
    (0, b'\x01\x00'),
    (1, b'\x02\x00'),
    (2, b'\x04\x00'),
    (3, b'\x08\x00'),
    (4, b'\x10\x00'),
    (5, b'\x20\x00'),
    (6, b'\x40\x00'),
    (7, b'\x80\x00'),
    (8, b'\x00\x01'),
    (9, b'\x00\x02'),
    (10, b'\x00\x04'),
    (11, b'\x00\x08'),
    (12, b'\x00\x10'),
    (13, b'\x00\x20'),
    (14, b'\x00\x40'),
    (15, b'\x00\x80'),
])
def test_set_get_qubit(bit_pos, expected_byte_array):
    sv = StateVector(16)
    assert sv._byte_array == b'\x00\x00'
    sv.set_qubit(bit_pos, 1)
    assert sv._byte_array == expected_byte_array

    for i in range(16):
        if i == bit_pos:
            assert sv.get_qubit(i) == 1
        else:
            assert sv.get_qubit(i) == 0

    # Try bit flipping on not bit string
    for i in range(16):
        sv.set_qubit(i, 1)

    assert sv._byte_array == b'\xFF\xFF'
    # flip bit at position to zero
    sv.set_qubit(bit_pos, 0)

    assert sv._byte_array == bytearray([(~b & 0xFF) for b in expected_byte_array])


def test_get_array_get_string():
    sv = StateVector(16)
    assert sv.get_array() == [0] * 16
    assert sv.get_string() == '0' * 16

    for i in range(16):
        sv.set_qubit(i, i % 2)
    assert sv.get_array() == [0, 1] * 8
    assert sv.get_string() == '01' * 8


def test_get_bytes():
    sv = StateVector(16)

    assert sv.get_bytes() == b'\x00\x00'
    assert sv.get_bytes() == sv._byte_array


def test_set_bytes():
    sv = StateVector(16)
    assert sv._byte_array == b'\x00\x00'
    sv.set_bytes(b'\xBE\xEF')

    assert sv._byte_array == b'\xBE\xEF'


def test_set_bytes_wrong_size():
    sv = StateVector(16)

    with pytest.raises(ValueError) as exc:
        sv.set_bytes(b'\00')

    assert exc.value.args[
               0] == "State vector with 16 bits should have a byte array of length 2 but bytes sent in have length 1"
