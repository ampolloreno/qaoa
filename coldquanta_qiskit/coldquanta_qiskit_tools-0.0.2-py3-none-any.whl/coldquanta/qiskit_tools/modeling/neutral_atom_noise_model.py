# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from qiskit.providers.aer.noise import NoiseModel
from qiskit.providers.aer.noise.errors import depolarizing_error, thermal_relaxation_error, kraus_error
from coldquanta.qiskit_tools.modeling.kraus_operators import create_neutral_cz_error_kraus

def create_noise_model(*,t1_time_s=0.5,
                       t2_time_s=0.01,
                       single_qubit_gate_time_s=50*(10**-6),
                       single_qubit_depolarizing_error=0.005,
                       cz_fidelity=0.95):
    noise_model = NoiseModel()


    single_qubit_error_t1_t2 = thermal_relaxation_error(t1=t1_time_s,
                                                        t2=t2_time_s,
                                                        time=single_qubit_gate_time_s)

    single_qubit_depolarizing_operator = depolarizing_error(single_qubit_depolarizing_error, 1)


    single_qubit_error = single_qubit_error_t1_t2.compose(single_qubit_depolarizing_operator)

    # Add single qubit noise
    noise_model.add_all_qubit_quantum_error(single_qubit_error, ["r"])
    noise_model.add_all_qubit_quantum_error(single_qubit_error, ["rz"])
    noise_model.add_all_qubit_quantum_error(single_qubit_error, ["id"])


    cz_kraus_operators = create_neutral_cz_error_kraus(fidelity=cz_fidelity)
    cz_error = kraus_error(cz_kraus_operators)
    noise_model.add_all_qubit_quantum_error(cz_error, ["cz"])

    return noise_model
