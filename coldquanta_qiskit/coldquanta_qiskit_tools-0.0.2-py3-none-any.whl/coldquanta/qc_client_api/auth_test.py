# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qc_client_api.auth import AuthInfo, ColdQuantaAuth
import tempfile

import jwt
import time
import pytest
import json

from unittest.mock import MagicMock


@pytest.fixture()
def temp_file():
    with tempfile.NamedTemporaryFile() as file:
        # do stuff with temp file
        yield file


def test_auth_info_contructor():
    ai = AuthInfo("token", "refresh_token")

    assert ai.access_token == "token"
    assert ai.refresh_token == "refresh_token"
    assert ai.time_slack_seconds == 300


def test_auth_info_to_dictionary():
    ai = AuthInfo("token", "refresh_token")

    dictionary = ai.to_dictionary()

    assert dictionary == {
        "access_token": "token",
        "refresh_token": "refresh_token"
    }


def test_auth_info_from_dictionary():
    dictionary = {
        "access_token": "token",
        "refresh_token": "refresh_token"
    }

    ai = AuthInfo.from_dictionary(dictionary)

    assert ai.access_token == "token"
    assert ai.refresh_token == "refresh_token"
    assert ai.time_slack_seconds == 300


def test_auth_info_is_valid_true():
    mock_time = time.time() + 302
    token = jwt.encode(payload={"exp": mock_time}, key='asdfsdf')
    ai = AuthInfo(token=token, refresh_token="refresh")
    assert ai.is_valid() == True


def test_auth_info_is_valid_false():
    mock_time = time.time() + 298
    token = jwt.encode(payload={"exp": mock_time}, key='asdfsdf')
    ai = AuthInfo(token=token, refresh_token="refresh")
    assert ai.is_valid() == False


def test_coldquanta_auth_constructor_empty():
    cqa = ColdQuantaAuth()
    assert ".coldquanta/cq_auth.json" in cqa.json_file_path
    assert cqa.okta_api is not None
    assert not hasattr(cqa, "auth_info")

def test_coldquanta_auth_constructor_with_path():
    cqa = ColdQuantaAuth(json_file_path="some_custom_path")
    assert cqa.json_file_path == "some_custom_path"
    assert cqa.okta_api is not None
    assert not hasattr(cqa, "auth_info")



def test_coldquanta_auth_set_credentials():
    cqa = ColdQuantaAuth()

    ai = AuthInfo("token", "refresh_token")
    assert not hasattr(cqa, "auth_info")

    cqa.set_credentials(ai)

    assert hasattr(cqa, "auth_info")
    assert cqa.auth_info == ai


def test_coldquanta_auth_set_credentials_not_auth_info():
    cqa = ColdQuantaAuth()

    ai = AuthInfo("token", "refresh_token")
    assert not hasattr(cqa, "auth_info")

    with pytest.raises(ValueError) as exc:
        cqa.set_credentials("not_auth_info")
    assert exc.value.args[0] == "credentials must be of type AuthInfo"


def test_coldquanta_auth_save_auth_to_file(temp_file):
    file_path = temp_file.name

    cqa = ColdQuantaAuth()
    cqa.json_file_path = file_path

    ai = AuthInfo("token", "refresh_token")

    cqa.set_credentials(ai)

    cqa.save_auth_to_file()

    # Were the credentials actually saved?
    assert json.loads(temp_file.read()) == {
        "access_token": "token",
        "refresh_token": "refresh_token"
    }


def test_coldquanta_auth_load_from_file(temp_file):
    file_path = temp_file.name

    cqa = ColdQuantaAuth()
    cqa.json_file_path = file_path

    mock_file_contents = {
        "access_token": "token",
        "refresh_token": "refresh_token"
    }

    file_contents = json.dumps(mock_file_contents)
    temp_file.write(file_contents.encode('utf-8'))
    temp_file.flush()

    cqa.load_auth_from_file()

    assert cqa.auth_info.access_token == "token"
    assert cqa.auth_info.refresh_token == "refresh_token"


def test_coldquanta_auth_load_from_file_not_exist(temp_file):
    file_path = temp_file.name + "asdfsdf"

    cqa = ColdQuantaAuth()
    cqa.json_file_path = file_path

    with pytest.raises(ValueError) as exc:
        cqa.load_auth_from_file()

    assert exc.value.args[
               0] == "The file {} does not exist. Please authenticate with the coldquanta API \"python client/cmd/coldquanta_authorize.py\"".format(
        file_path)


def test_get_token_expired(temp_file):
    cqa = ColdQuantaAuth()

    mock_time = time.time() + 298
    token = jwt.encode(payload={"exp": mock_time}, key='asdfsdf')
    ai = AuthInfo(token=token, refresh_token="old_refresh")

    cqa.json_file_path = temp_file.name

    # Set credentials to ones that are invalid
    cqa.set_credentials(ai)

    cqa.okta_api = MagicMock()

    mock_new_credentials = {"access_token": "new_access_token",
                            "refresh_token": "new_refresh_token"}
    cqa.okta_api.refresh_token.return_value = mock_new_credentials

    # This should return the new credentials from the mock api request
    assert cqa.get_token() == "new_access_token"

    # Was the okta api called to perform the refresh?
    cqa.okta_api.refresh_token.assert_called_once_with("old_refresh")

    assert cqa.auth_info.access_token == "new_access_token"
    assert cqa.auth_info.refresh_token == "new_refresh_token"

    # Were the new credentials actually saved to disk?
    assert json.loads(temp_file.read()) == {
        "access_token": "new_access_token",
        "refresh_token": "new_refresh_token"
    }


def test_get_token_not_expired(temp_file):
    cqa = ColdQuantaAuth()

    mock_time = time.time() + 302
    original_token = jwt.encode(payload={"exp": mock_time}, key='asdfsdf')
    ai = AuthInfo(token=original_token, refresh_token="old_refresh")

    cqa.json_file_path = temp_file.name

    # Set credentials to ones that are invalid
    cqa.set_credentials(ai)

    cqa.okta_api = MagicMock()

    mock_new_credentials = {"access_token": "new_access_token",
                            "refresh_token": "new_refresh_token"}
    cqa.okta_api.refresh_token.return_value = mock_new_credentials

    # This should return the new credentials from the mock api request
    assert cqa.get_token() == original_token

    # The refresh should not have been performed
    assert cqa.okta_api.refresh_token.called == False

    # The credentials should not have rotated
    assert cqa.auth_info.access_token == original_token
    assert cqa.auth_info.refresh_token == "old_refresh"

    # The credentials should not have been saved
    assert temp_file.read() == b''
