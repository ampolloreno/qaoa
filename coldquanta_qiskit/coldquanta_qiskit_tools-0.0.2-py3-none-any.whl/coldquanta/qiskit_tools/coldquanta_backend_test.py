# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qiskit_tools.coldquanta_backend import ColdQuantaBackend, ColdQuantaJob
from qiskit import *
from unittest.mock import MagicMock
from coldquanta.qc_client_api.protos import qc_client_api_pb2
from coldquanta.qc_client_api.common.state_vector import StateVector
import math
from uuid import uuid4
import pytest


@pytest.fixture
def mock_qpu_state():
    qubits = [qc_client_api_pb2.QubitData(qubit_id=0),
              qc_client_api_pb2.QubitData(qubit_id=1)]
    cz_connections = [qc_client_api_pb2.CZConnection(qubit_a=0, qubit_b=1)]

    gate_configuration = qc_client_api_pb2.GateConfiguration(qubits=qubits, cz_connections=cz_connections)
    qpu_state = qc_client_api_pb2.QPUState(gate_configuration=gate_configuration, max_shots=100)

    return qpu_state


def test_constructor(mock_qpu_state):
    # Create a mock qpu
    mock_qpu_id = str(uuid4())
    qpu_list = [qc_client_api_pb2.QPU(name="madison", id=mock_qpu_id, status=qc_client_api_pb2.QPUStatus.ONLINE,
                                      qpu_state=mock_qpu_state)]
    qpu_array_message = qc_client_api_pb2.QPUArray(qpus=qpu_list)

    cq_api = MagicMock()
    cq_api.list_qpus.return_value = qpu_array_message

    # Create the backend
    backend = ColdQuantaBackend(cq_api=cq_api, qpu_id=mock_qpu_id)

    assert backend.cold_quanta_api == cq_api
    assert backend._configuration.backend_name == "madison"
    assert backend._configuration.backend_version == "1.0.0"
    assert backend._configuration.n_qubits == 2
    assert backend._configuration.basis_gates == ["id", "cz", "r", "rz"]

    assert len(backend._configuration.gates) == 4

    g_0 = backend._configuration.gates[0]
    assert g_0.name == "id"
    assert g_0.parameters == []
    assert g_0.qasm_def == 'gate id q { U(0,0,0) q; }'
    assert g_0.coupling_map == [[0], [1]]

    g_1 = backend._configuration.gates[1]
    assert g_1.name == "cz"
    assert g_1.parameters == []
    assert g_1.qasm_def == 'gate cz q1,q2 { CZ q1,q2; }'
    assert g_1.coupling_map == [[0, 1]]

    g_2 = backend._configuration.gates[2]
    assert g_2.name == "r"
    assert g_2.parameters == ["theta", "phi"]
    assert g_2.qasm_def == 'gate r(theta, phi) q { R(theta, phi) q; }'
    assert g_2.coupling_map == [[0], [1]]

    g_3 = backend._configuration.gates[3]
    assert g_3.name == "rz"
    assert g_3.parameters == ["phi"]
    assert g_3.qasm_def == 'gate rz(phi) q { RZ(phi) q; }'
    assert g_3.coupling_map == [[0], [1]]

    assert backend._configuration.max_shots == 100
    assert backend._configuration.coupling_map == [[0, 1]]


@pytest.mark.parametrize("mock_qpu_status", [
    qc_client_api_pb2.QPUStatus.ONLINE,
    qc_client_api_pb2.QPUStatus.OFFLINE
])
def test_get_backend_status(mock_qpu_state, mock_qpu_status):
    # Create a mock qpu
    mock_qpu_id = str(uuid4())
    qpu_list = [
        qc_client_api_pb2.QPU(name="madison", id=mock_qpu_id, status=mock_qpu_status, qpu_state=mock_qpu_state)]
    qpu_array_message = qc_client_api_pb2.QPUArray(qpus=qpu_list)

    cq_api = MagicMock()
    cq_api.list_qpus.return_value = qpu_array_message

    # Create the backend
    backend = ColdQuantaBackend(cq_api=cq_api, qpu_id=mock_qpu_id)

    backend_status = backend.status()

    assert backend_status.backend_name == "madison"
    assert backend_status.backend_version == "1.0.0"
    if mock_qpu_status == qc_client_api_pb2.QPUStatus.ONLINE:
        assert backend_status.operational == True
    if mock_qpu_status == qc_client_api_pb2.QPUStatus.OFFLINE:
        assert backend_status.operational == False
    assert backend_status.pending_jobs == 0
    assert backend_status.status_msg == ""


def test_run_circuit(mock_qpu_state):
    # Create a mock qpu
    mock_qpu_id = str(uuid4())
    qpu_list = [qc_client_api_pb2.QPU(name="madison", id=mock_qpu_id, status=qc_client_api_pb2.QPUStatus.ONLINE,
                                      qpu_state=mock_qpu_state)]
    qpu_array_message = qc_client_api_pb2.QPUArray(qpus=qpu_list)

    # Create mock api
    cq_api = MagicMock()
    cq_api.list_qpus.return_value = qpu_array_message

    mock_new_job_id = str(uuid4())
    cq_api.submit_job.return_value = mock_new_job_id

    # Create the backend
    backend = ColdQuantaBackend(cq_api=cq_api, qpu_id=mock_qpu_id)

    # TODO -> test that _configuration attribute is correct
    circ = QuantumCircuit(2)
    circ.ry(q=0, theta=math.pi / 2)
    circ.rx(q=1, theta=math.pi / 2)
    circ.rz(q=1, phi=-math.pi / 2)
    circ.cz(0, 1)
    circ.cz(1, 0)
    circ.measure_all()

    job = qiskit.execute(circ, backend, optimization_level=0)

    assert isinstance(job, ColdQuantaJob)
    assert job._job_id == mock_new_job_id
    assert job._backend == backend

    expected_gates = []
    expected_gates.append(
        qc_client_api_pb2.Gate(r=qc_client_api_pb2.GateR(qubit=0, theta=math.pi / 2, phi=math.pi / 2)))
    expected_gates.append(qc_client_api_pb2.Gate(r=qc_client_api_pb2.GateR(qubit=1, theta=math.pi / 2, phi=0)))
    expected_gates.append(qc_client_api_pb2.Gate(rz=qc_client_api_pb2.GateRZ(qubit=1, phi=-math.pi / 2)))
    expected_gates.append(qc_client_api_pb2.Gate(cz=qc_client_api_pb2.GateCZ(qubit_a=0, qubit_b=1)))
    expected_gates.append(qc_client_api_pb2.Gate(cz=qc_client_api_pb2.GateCZ(qubit_a=1, qubit_b=0)))
    expected_circuit = qc_client_api_pb2.Circuit(gates=expected_gates)
    expected_job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id=mock_qpu_id),
                                                               circuit=expected_circuit,
                                                               shots=1024)

    cq_api.submit_job.assert_called_once_with(job_input_message=expected_job_input_message,
                                              qpu_state_message=mock_qpu_state)

    # Create a mock response from the API

    mock_job_input = expected_job_input_message
    mock_state_counts = []

    index = 0
    for state in [[0, 1], [1, 0], [0, 0], [1, 1]]:
        new_state_vector = StateVector(number_qubits=2)
        new_state_vector.set_qubit(qubit=0, value=state[0])
        new_state_vector.set_qubit(qubit=1, value=state[1])

        state_vector_message = qc_client_api_pb2.stateVector(byte_array=new_state_vector.get_bytes(), bits=2)
        new_state_count = qc_client_api_pb2.StateCount(state_vector=state_vector_message, count=index)

        mock_state_counts.append(new_state_count)

        index += 1

    mock_job_output = qc_client_api_pb2.QPUJobOutput(state_counts=mock_state_counts)

    mock_qpu_job_message_not_complete = qc_client_api_pb2.QPUJob(status=qc_client_api_pb2.QPUJob.Status.RUNNING,
                                                                 input=mock_job_input,
                                                                 output=qc_client_api_pb2.QPUJobOutput())

    mock_qpu_job_message_complete = qc_client_api_pb2.QPUJob(status=qc_client_api_pb2.QPUJob.Status.COMPLETE,
                                                             input=mock_job_input,
                                                             output=mock_job_output)

    cq_api.get_job.side_effect = [mock_qpu_job_message_not_complete,
                                  mock_qpu_job_message_not_complete,
                                  mock_qpu_job_message_not_complete,
                                  mock_qpu_job_message_complete,
                                  mock_qpu_job_message_complete]

    # Calling .result causes api requests

    # don't actually wait between requests
    job._delay = MagicMock()
    qiskit_result_object = job.result()

    assert cq_api.get_job.call_count == 5
    for call_args in cq_api.get_job.call_args_list:
        assert call_args[1]["job_id"] == mock_new_job_id

    assert qiskit_result_object.get_counts() == {
        '01': 0,
        '10': 1,
        '00': 2,
        '11': 3
    }
