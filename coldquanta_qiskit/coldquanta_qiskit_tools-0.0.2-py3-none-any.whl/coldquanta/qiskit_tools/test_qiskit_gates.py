# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from qiskit import QuantumCircuit, Aer
import qiskit
import math
import pytest

import numpy as np


def get_r_gate_unitary(theta, phi):
    circ_r_gate = QuantumCircuit(1)
    circ_r_gate.r(q=0, phi=phi, theta=theta)

    backend = Aer.get_backend('unitary_simulator')

    job = qiskit.execute(circ_r_gate, backend)
    result = job.result()
    unitary = result.get_unitary(circ_r_gate)

    return unitary


def get_rx_gate_unitary(theta):
    circ_r_gate = QuantumCircuit(1)
    circ_r_gate.rx(q=0, theta=theta)

    backend = Aer.get_backend('unitary_simulator')

    job = qiskit.execute(circ_r_gate, backend)
    result = job.result()
    unitary = result.get_unitary(circ_r_gate)

    return unitary


def get_ry_gate_unitary(theta):
    circ_r_gate = QuantumCircuit(1)
    circ_r_gate.ry(q=0, theta=theta)

    backend = Aer.get_backend('unitary_simulator')

    job = qiskit.execute(circ_r_gate, backend)
    result = job.result()
    unitary = result.get_unitary(circ_r_gate)

    return unitary


@pytest.mark.parametrize("rotation", [
    0.0,
    0.1,
    -0.1,
    math.pi / 2,
    -math.pi / 2,
    math.pi,
    -math.pi,
    2 * math.pi,
    -2 * math.pi
])
def test_r_gate_rx_gate_equivalence(rotation):
    # rx is a case of the r gate where phi=0
    u_r = get_r_gate_unitary(phi=0, theta=rotation)
    u_rx = get_rx_gate_unitary(theta=rotation)

    assert np.allclose(u_r, u_rx)


@pytest.mark.parametrize("rotation", [
    0.0,
    0.1,
    -0.1,
    math.pi / 2,
    -math.pi / 2,
    math.pi,
    -math.pi,
    2 * math.pi,
    -2 * math.pi
])
def test_r_gate_ry_gate_equivalence(rotation):
    # rx is a case of the r gate where phi=pi/2
    u_r = get_r_gate_unitary(phi=math.pi / 2, theta=rotation)
    u_ry = get_ry_gate_unitary(theta=rotation)

    assert np.allclose(u_r, u_ry)
