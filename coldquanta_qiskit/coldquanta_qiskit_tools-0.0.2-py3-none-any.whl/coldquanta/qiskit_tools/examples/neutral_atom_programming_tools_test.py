from coldquanta.qiskit_tools.examples.test_tools import run_notebook
import os

def test_neutral_atom_programming_tools_notebook():

    base_path = os.path.abspath(os.path.dirname(__file__))

    nb, errors = run_notebook(os.path.join(base_path, 'neutral_atom_programming_tools.ipynb'))

    assert len(errors) == 2
    assert errors[0].evalue == 'CZ gate between qubits 0 and 3 is not possible'
    assert errors[1].evalue == 'Circuit operation rx has no equivalent in the neutral atom gateset [\'id\', \'cz\', \'r\', \'rz\', \'measure\', \'barrier\']'