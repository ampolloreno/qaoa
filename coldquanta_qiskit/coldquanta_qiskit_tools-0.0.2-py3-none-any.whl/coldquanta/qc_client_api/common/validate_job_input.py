# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qc_client_api.protos import qc_client_api_pb2

def is_job_input_valid(*, job_input, qpu_state):
    """

    :param job_input: job_input message
    :type job_input: coldquanta.common.protos.qc_client_api_pb2.QPUJobInput
    :param qpu_state: current state of the qpu message
    :type qpu_state: coldquanta.common.protos.qc_client_api_pb2.QPUState
    :return:
    """

    if not isinstance(job_input, qc_client_api_pb2.QPUJobInput):
        raise ValueError("job_input must be a qc_client_api_pb2.QPUJobInput object")

    if not isinstance(qpu_state, qc_client_api_pb2.QPUState):
        raise ValueError("qpu_state must be a q_api_pbs.QPUState object")

    physical_qubits = qpu_state.gate_configuration.qubits
    cz_connections = qpu_state.gate_configuration.cz_connections

    unique_physical_qubits = set()
    for qubit in physical_qubits:
        unique_physical_qubits.add(qubit.qubit_id)

    valid_connections = set()
    for connection in cz_connections:
        a = connection.qubit_a
        b = connection.qubit_b
        edge_forward = (a, b)
        edge_reverse = (b, a)
        valid_connections.add(edge_forward)
        valid_connections.add(edge_reverse)

    circuit = job_input.circuit

    if len(circuit.gates) == 0:
        return False, "Circuit has no gates"

    if len(circuit.gates) > 100:
        return False, "Circuit depth cannot exceed 100"

    for gate in circuit.gates:
        gate_type = gate.WhichOneof("gate")
        if gate_type == "cz":
            qubit_a = gate.cz.qubit_a
            qubit_b = gate.cz.qubit_b
            gate_edge = (qubit_a, qubit_b)

            if gate_edge not in valid_connections:
                message = "CZ gate between qubits {} and {} is not possible".format(qubit_a, qubit_b)
                return False, message

        # For each single qubit gate, check that the qubit exists
        for single_qubit_gate_type in ["r", "rz", "id"]:
            if gate_type == single_qubit_gate_type:
                qubit_id = getattr(gate, single_qubit_gate_type).qubit
                if qubit_id not in unique_physical_qubits:
                    message = "Qubit {} does not exist on physical hardware. Cannot perform gate {}".format(qubit_id,
                                                                                                            single_qubit_gate_type)
                    return False, message

    return True, ''
