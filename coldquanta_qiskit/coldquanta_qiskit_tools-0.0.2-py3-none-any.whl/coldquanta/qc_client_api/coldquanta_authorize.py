# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qc_client_api.common.auth.okta.okta_api import AuthTools, OktaAPI
from coldquanta.qc_client_api.auth import AuthInfo, ColdQuantaAuth
from flask import Flask, request
import webbrowser
import threading
import time

import os


def exit_in_time(t):
    time.sleep(t)
    os._exit(0)


def run_server(verifier, callback):
    stop_thread = threading.Thread(target=exit_in_time, args=(1,))

    app = Flask(__name__)

    @app.route('/')
    def auth_window():
        try:
            temporary_access_code = request.args.get('code')
            callback(temporary_access_code, verifier)
            print("authentication complete!, you can now close your web browser")
            stop_thread.start()
            return 'authentication complete! you can now close this window'
        except:
            stop_thread.start()
            return 'something went wrong while authenticating, please contact coldquanta', 400

    app.run(port=8080, debug=False)


class AuthCommand():

    def __init__(self):
        self.okta_api = OktaAPI()

    def authenticate(self):
        """
        Run the localhost authentication flow
        :return:
        """
        auth_tools = AuthTools()
        verifier = auth_tools._generate_verifier(80)
        challenge = auth_tools._generate_challenge(verifier)

        web_authorization_url = auth_tools.get_auth_url(challenge)

        print(
            "Opening up your webbrowser to authenticate.\n If you don't see a webbrowser appear, please navigate to the following url:\n{}\n".format(
                web_authorization_url))
        webbrowser.open(web_authorization_url)

        run_server(verifier, self._handle_temporary_access_code)

    def _handle_temporary_access_code(self, temporary_access_code, verifier):
        new_credentials_dictionary = self.okta_api.get_new_credentials(temporary_access_code=temporary_access_code,
                                                                       verifier=verifier)

        # Create a new auth object
        cold_quanta_auth = ColdQuantaAuth()

        # Update credentials
        cold_quanta_credentials = AuthInfo.from_dictionary(new_credentials_dictionary)
        cold_quanta_auth.set_credentials(cold_quanta_credentials)

        # Persist to disk
        cold_quanta_auth.save_auth_to_file()


if __name__ == "__main__":
    auth_command = AuthCommand()
    auth_command.authenticate()
