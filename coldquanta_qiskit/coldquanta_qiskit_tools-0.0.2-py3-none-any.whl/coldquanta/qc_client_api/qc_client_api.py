# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qc_client_api.protos import qc_client_api_pb2
from coldquanta.qc_client_api.common.validate_job_input import is_job_input_valid
import requests
import urllib.parse


class QCClientAPI():
    def __init__(self, *, authentication):
        """
        :param authentication: python object with a get_token() method such as source.client.common.auth.auth.ColdQuantaAuth
        """
        self.api_base_url = "https://www.coldquantaapis.com/api/v1/qos/user/"
        self.authentication = authentication

    def list_qpus(self):
        # Send request
        response_message_bytes = self._common_rpc("list_qpu", b'')

        # Parse response
        qpu_array_message = qc_client_api_pb2.QPUArray()
        qpu_array_message.ParseFromString(response_message_bytes)
        return qpu_array_message

    def submit_job(self, *, job_input_message, qpu_state_message):
        """
        # Submit a circuit job
        :param job_input_message: coldquanta.common.protos.qc_client_api_pb2.
        :return: string of job id
        """

        # Check job input type
        if not isinstance(job_input_message, qc_client_api_pb2.QPUJobInput):
            raise ValueError("job input is not of type qc_client_api_pb2.QPUJobInput")

        is_valid, message = is_job_input_valid(job_input=job_input_message, qpu_state=qpu_state_message)

        if not is_valid:
            raise ValueError("Job circuit is not valid: {}".format(message))

        request_bytes = job_input_message.SerializeToString()

        response_message_bytes = self._common_rpc("submit_job", request_bytes)

        # Decode response
        qpu_job_id_message = qc_client_api_pb2.QPUJobId()
        qpu_job_id_message.ParseFromString(response_message_bytes)

        return qpu_job_id_message.job_id

    def get_job(self, *, job_id):
        """

        :param job_id: string
        :return: source.interface.protos.q_api_pb.QPUJob
        """

        if not isinstance(job_id, str):
            raise ValueError("job_id must be a UUID4 string")

        # Create request
        qpu_job_id_message = qc_client_api_pb2.QPUJobId(job_id=job_id)
        request_bytes = qpu_job_id_message.SerializeToString()

        # Make request
        response_bytes = self._common_rpc("get_job", request_bytes)

        # Parse response
        qpu_job_message = qc_client_api_pb2.QPUJob()
        qpu_job_message.ParseFromString(response_bytes)

        return qpu_job_message

    def cancel_job(self, *, job_id):

        if not isinstance(job_id, str):
            raise ValueError("job_id must be a UUID4 string")

            # Create request
        qpu_job_id_message = qc_client_api_pb2.QPUJobId(job_id=job_id)
        request_bytes = qpu_job_id_message.SerializeToString()

        self._common_rpc("cancel_job", request_bytes)

    def _get_token(self):
        return self.authentication.get_token()

    def _common_rpc(self, url_sub_path, input_bytes):
        """

        :param url_sub_path: request route
        :param input_bytes: byte string
        :return: output_bytes: byte string
        """
        url = urllib.parse.urljoin(self.api_base_url, url_sub_path)

        auth_token = self._get_token()

        auth_header = "Bearer " + auth_token

        headers = {
            "content-type": "application/proto",
            "authorization": auth_header
        }

        resp = requests.post(url=url, data=input_bytes, headers=headers)

        if resp.status_code != 200:
            print(resp.text)

        # Raise exception if non 200 status code
        resp.raise_for_status()

        output_bytes = resp.content
        return output_bytes
