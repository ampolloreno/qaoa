# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qc_client_api.protos import qc_client_api_pb2


def x_y_to_index(cols, x, y):
    return x * cols + y


def generate_cz_pairs(*, rows, cols):
    """
    Generate a set of cz connection pairs for a grid of size rows x cols
    :param rows: number of grid rows
    :param cols: number of grid cols
    :return: array of elements, where each element is a pair of [<qubit_a index>, <qubit_b_index>]
    """
    cz_pairs = []

    for row in range(rows):
        for col in range(cols - 1):
            a_index = x_y_to_index(cols, row, col)
            b_index = x_y_to_index(cols, row, col + 1)
            cz_pairs.append([a_index, b_index])

    for row in range(rows - 1):
        for col in range(cols):
            a_index = x_y_to_index(cols, row, col)
            b_index = x_y_to_index(cols, row + 1, col)
            cz_pairs.append([a_index, b_index])

    return cz_pairs


def generate_gate_configuration(*, rows, cols):
    number_qubits = rows * cols
    cz_connections = generate_cz_pairs(rows=rows, cols=cols)

    # Most circuit frameworks need explicit directed edges instead of single undirected edge
    # since superconductors have directional couplers. So duplicate edges in opposite direction.
    cz_connections += [list(reversed(connection)) for connection in cz_connections]

    qubits = []
    for i in range(number_qubits):
        qubits.append(qc_client_api_pb2.QubitData(qubit_id=i))

    cz_connection_messages = []
    for connection in cz_connections:
        a = connection[0]
        b = connection[1]
        cz_connection_messages.append(qc_client_api_pb2.CZConnection(qubit_a=a, qubit_b=b))

    gate_configuration = qc_client_api_pb2.GateConfiguration(qubits=qubits, cz_connections=cz_connection_messages)

    return gate_configuration


def generate_qpu_state(*, rows, cols, max_shots):
    gate_configuration = generate_gate_configuration(rows=rows, cols=cols)
    qpu_state = qc_client_api_pb2.QPUState(gate_configuration=gate_configuration, max_shots=max_shots)
    return qpu_state
