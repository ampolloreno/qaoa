# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import json
import jwt
import time
from coldquanta.qc_client_api.common.auth.okta.okta_api import OktaAPI

DEFAULT_CREDENTIAL_PATH = os.path.join(os.path.expanduser("~"), ".coldquanta", "cq_auth.json")


class AuthInfo():
    def __init__(self, token, refresh_token):
        """
        :param token: string that must be attached to outbound request headers to allow access
        :param refresh_token: string that can be exchanged for a new access token when the current access token expires
        """

        self.access_token = token
        self.refresh_token = refresh_token

        # Refresh token 5 minutes before needed so requests don't fail
        self.time_slack_seconds = 5 * 60

    def is_valid(self):
        """
        Determine if the current access token is expired.
        This is a client side method only and should NOT be used
        for server side for verification.

        :return: Boolean
        """

        current_time = time.time()

        jwt_payload = jwt.decode(self.access_token, verify=False)
        token_expire = jwt_payload["exp"]

        # Will the access token expire within time_slack_seconds from now?
        if current_time > (token_expire - self.time_slack_seconds):
            # If the access token will expire soon, trigger a refresh
            return False
        else:
            # Else continue to use the current access token
            return True

    @staticmethod
    def from_dictionary(json_contents):
        return AuthInfo(json_contents["access_token"], json_contents["refresh_token"])

    def to_dictionary(self):
        return {
            "access_token": self.access_token,
            "refresh_token": self.refresh_token
        }


class ColdQuantaAuth():
    def __init__(self, *, json_file_path=DEFAULT_CREDENTIAL_PATH):
        self.json_file_path = json_file_path
        self.okta_api = OktaAPI()

    def set_credentials(self, credentials):
        """
        :param credentials: AuthInfo object
        :return: None
        """

        if not isinstance(credentials, AuthInfo):
            raise ValueError("credentials must be of type AuthInfo")

        self.auth_info = credentials

    def load_auth_from_file(self):
        if not os.path.isfile(self.json_file_path):
            raise ValueError(
                "The file {} does not exist. Please authenticate with the coldquanta API \"python client/cmd/coldquanta_authorize.py\"".format(
                    self.json_file_path))

        with open(self.json_file_path) as f:
            auth_dictionary = json.load(f)
            auth_info = AuthInfo.from_dictionary(auth_dictionary)

        self.auth_info = auth_info

    def save_auth_to_file(self):
        os.makedirs(os.path.dirname(self.json_file_path), exist_ok=True)
        with open(self.json_file_path, "w") as f:
            auth_dictionary = self.auth_info.to_dictionary()
            json.dump(auth_dictionary, f)

    def _refresh_token(self, auth_info):
        """

        :param auth_info: Current AuthInfo object
        :return: Refreshed AuthInfo object
        """
        new_credentials_dictionary = self.okta_api.refresh_token(auth_info.refresh_token)
        new_auth_info = AuthInfo.from_dictionary(new_credentials_dictionary)
        return new_auth_info

    def get_token(self):
        if not self.auth_info.is_valid():
            self.auth_info = self._refresh_token(self.auth_info)
            self.save_auth_to_file()

        return self.auth_info.access_token
