# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qc_client_api.qc_client_api import QCClientAPI
from coldquanta.qc_client_api.protos import qc_client_api_pb2
import pytest
from unittest.mock import patch


@pytest.fixture()
def mock_auth():
    class MockAuth():
        def __init__(self):
            pass

        def get_token(self):
            return "token"

    yield MockAuth()


def test_constuctor(mock_auth):
    api = QCClientAPI(authentication=mock_auth)


@pytest.fixture
def mock_qpu_state():
    qubits = [qc_client_api_pb2.QubitData(qubit_id=0),
              qc_client_api_pb2.QubitData(qubit_id=1)]
    cz_connections = [qc_client_api_pb2.CZConnection(qubit_a=0, qubit_b=1)]

    gate_configuration = qc_client_api_pb2.GateConfiguration(qubits=qubits, cz_connections=cz_connections)

    qpu_state = qc_client_api_pb2.QPUState(gate_configuration=gate_configuration, max_shots=100)

    return qpu_state


@pytest.fixture
def mock_job_input():
    gates = []
    gates.append(qc_client_api_pb2.Gate(id=qc_client_api_pb2.GateID(qubit=0)))
    gates.append(qc_client_api_pb2.Gate(cz=qc_client_api_pb2.GateCZ(qubit_a=0, qubit_b=1)))
    gates.append(qc_client_api_pb2.Gate(r=qc_client_api_pb2.GateR(qubit=1, theta=0.5, phi=0.5)))
    gates.append(qc_client_api_pb2.Gate(gr=qc_client_api_pb2.GateGR(theta=0.5, phi=0.5)))

    circuit_message = qc_client_api_pb2.Circuit(gates=gates)

    job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id="some_id"),
                                                      circuit=circuit_message,
                                                      shots=200)

    return job_input_message


def test_list_qpu(mock_auth, mock_qpu_state):
    api = QCClientAPI(authentication=mock_auth)

    with patch('coldquanta.qc_client_api.qc_client_api.requests.post') as mock_post:
        qpu_list = []

        qpu_list.append(qc_client_api_pb2.QPU(name="hilbert",
                                              id="some_id",
                                              status=qc_client_api_pb2.QPUStatus.ONLINE,
                                              qpu_state=mock_qpu_state))
        mock_qpu_array = qc_client_api_pb2.QPUArray(qpus=qpu_list)
        mock_response_bytes = mock_qpu_array.SerializeToString()

        # Mock requests response
        mock_post.return_value.content = mock_response_bytes

        qpu_list_message = api.list_qpus()

        # Was requests called correctly?
        mock_post.assert_called_once_with(url=api.api_base_url + "list_qpu", data=b'',
                                          headers={'content-type': 'application/proto',
                                                   'authorization': 'Bearer token'})

        assert len(qpu_list_message.qpus) == 1
        assert qpu_list_message.qpus[0].id == "some_id"
        assert qpu_list_message.qpus[0].name == "hilbert"
        assert qpu_list_message.qpus[0].status == qc_client_api_pb2.QPUStatus.ONLINE


def test_submit_job(mock_auth, mock_job_input, mock_qpu_state):
    api = QCClientAPI(authentication=mock_auth)

    with patch('coldquanta.qc_client_api.qc_client_api.requests.post') as mock_post:
        qpu_list = []

        mock_qpu_id = qc_client_api_pb2.QPUJobId(job_id="some_id")
        mock_response_bytes = mock_qpu_id.SerializeToString()

        # Mock requests response
        mock_post.return_value.content = mock_response_bytes

        job_input_message = mock_job_input

        # Submit job
        qpu_job_id = api.submit_job(job_input_message=job_input_message, qpu_state_message=mock_qpu_state)

        # Was requests called correctly?
        mock_post.assert_called_once_with(url=api.api_base_url + "submit_job",
                                          data=job_input_message.SerializeToString(),
                                          headers={'content-type': 'application/proto',
                                                   'authorization': 'Bearer token'})

        assert qpu_job_id == "some_id"


def test_submit_job_not_proto_message(mock_auth):
    api = QCClientAPI(authentication=mock_auth)

    with patch('coldquanta.qc_client_api.qc_client_api.requests.post') as mock_post:
        with pytest.raises(ValueError) as exc:
            # Submit job
            api.submit_job(job_input_message="not a proto message", qpu_state_message=None)

        assert exc.value.args[0] == "job input is not of type qc_client_api_pb2.QPUJobInput"


def test_submit_job_circuit_invalid(mock_auth, mock_qpu_state):
    api = QCClientAPI(authentication=mock_auth)

    with patch('coldquanta.qc_client_api.qc_client_api.requests.post') as mock_post:
        qpu_list = []

        mock_qpu_id = qc_client_api_pb2.QPUJobId(job_id="some_id")
        mock_response_bytes = mock_qpu_id.SerializeToString()

        # Mock requests response
        mock_post.return_value.content = mock_response_bytes

        # Create a circuit with incorrect connectivity

        gates = []
        gates.append(qc_client_api_pb2.Gate(cz=qc_client_api_pb2.GateCZ(qubit_a=1, qubit_b=2)))

        circuit_message = qc_client_api_pb2.Circuit(gates=gates)

        job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id="some_id"),
                                                          circuit=circuit_message,
                                                          shots=200)

        # Submit job

        with pytest.raises(ValueError) as exc:
            qpu_job_id = api.submit_job(job_input_message=job_input_message, qpu_state_message=mock_qpu_state)

        exc.value.args[0][0] == "Job circuit is not valid: CZ gate between qubits 1 and 2 is not possible"


def test_get_job(mock_auth):
    api = QCClientAPI(authentication=mock_auth)

    with patch('coldquanta.qc_client_api.qc_client_api.requests.post') as mock_post:
        mock_qpu = qc_client_api_pb2.QPUJob()
        mock_response_bytes = mock_qpu.SerializeToString()

        mock_post.return_value.content = mock_response_bytes

        qpu_job_response = api.get_job(job_id="some_id")

        expected_qpu_job_id_message = qc_client_api_pb2.QPUJobId(job_id="some_id")

        # Was requests called correctly?
        mock_post.assert_called_once_with(url=api.api_base_url + "get_job",
                                          data=expected_qpu_job_id_message.SerializeToString(),
                                          headers={'content-type': 'application/proto',
                                                   'authorization': 'Bearer token'})

        assert qpu_job_response.status == qc_client_api_pb2.QPUJob.Status.PENDING

        # TODO -> verify that job contents are correct


def test_get_job_job_id_not_string(mock_auth):
    api = QCClientAPI(authentication=mock_auth)

    with patch('coldquanta.qc_client_api.qc_client_api.requests.post') as mock_post:
        with pytest.raises(ValueError) as exc:
            qpu_job_response = api.get_job(job_id=3)

        assert exc.value.args[0] == "job_id must be a UUID4 string"


def test_cancel_job(mock_auth):
    api = QCClientAPI(authentication=mock_auth)

    with patch('coldquanta.qc_client_api.qc_client_api.requests.post') as mock_post:
        # Mock requests response
        mock_post.return_value.content = ''

        # Cancel job
        api.cancel_job(job_id="some_id")

        expected_qpu_job_id_message = qc_client_api_pb2.QPUJobId(job_id="some_id")
        # Was requests called correctly?
        mock_post.assert_called_once_with(url=api.api_base_url + "cancel_job",
                                          data=expected_qpu_job_id_message.SerializeToString(),
                                          headers={'content-type': 'application/proto',
                                                   'authorization': 'Bearer token'})
