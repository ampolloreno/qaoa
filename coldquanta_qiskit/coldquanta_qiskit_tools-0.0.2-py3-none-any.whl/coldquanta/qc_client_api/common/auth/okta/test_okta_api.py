# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qc_client_api.common.auth.okta.okta_api import OktaAPI
from unittest.mock import patch, MagicMock
import pytest
import base64

from requests.exceptions import HTTPError


def test_constructor():
    okta = OktaAPI()


def test_get_credentials():
    with patch('coldquanta.qc_client_api.common.auth.okta.okta_api.requests.post') as mock_post:
        # Mock okta response
        mock_okta_response_json = {
            "access_token": "mock_access_token",
            "refresh_token": "mock_refresh_token"
        }

        mock_response = MagicMock()

        mock_response.json.return_value = mock_okta_response_json
        mock_post.return_value = mock_response

        okta = OktaAPI()

        mock_temporary_access_code = "abcd123"
        mock_verifier = "verify"

        # Call method
        credential_dictionary = okta.get_new_credentials(verifier=mock_verifier,
                                                         temporary_access_code=mock_temporary_access_code)

        assert credential_dictionary == mock_okta_response_json
        assert mock_post.called == True

        mock_post.assert_called_once_with('https://dev-528090.okta.com/oauth2/default/v1/token',
                                          allow_redirects=False,
                                          data={'grant_type': 'authorization_code', 'client_id': '0oa2cwiq69NG0o022357',
                                                'redirect_uri': 'http://localhost:8080',
                                                'code': mock_temporary_access_code, 'code_verifier': mock_verifier},
                                          headers={'accept': 'application/json', 'cache-control': 'no-cache',
                                                   'content-type': 'application/x-www-form-urlencoded'})


def test_get_credentials_fails():
    with patch('coldquanta.qc_client_api.common.auth.okta.okta_api.requests.post') as mock_post:
        mock_post.side_effect = HTTPError()

        okta = OktaAPI()

        mock_temporary_access_code = "abcd123"
        mock_verifier = "verify"

        with pytest.raises(HTTPError):
            # Call method
            okta.get_new_credentials(verifier=mock_verifier, temporary_access_code=mock_temporary_access_code)

        assert mock_post.called == True


def test_refresh_token():
    with patch('coldquanta.qc_client_api.common.auth.okta.okta_api.requests.post') as mock_post:
        # Mock okta response
        mock_okta_response_json = {
            "access_token": "mock_access_token",
            "refresh_token": "mock_refresh_token"
        }

        mock_response = MagicMock()

        mock_response.json.return_value = mock_okta_response_json
        mock_post.return_value = mock_response

        okta = OktaAPI()

        mock_refresh_token = "initial_refresh_token"

        # Call method
        credential_dictionary = okta.refresh_token(mock_refresh_token)

        assert credential_dictionary == mock_okta_response_json
        assert mock_post.called == True

        mock_post.assert_called_once_with('https://dev-528090.okta.com/oauth2/default/v1/token',
                                          allow_redirects=False,
                                          data={'grant_type': 'refresh_token', 'refresh_token': mock_refresh_token,
                                                'client_id': '0oa2cwiq69NG0o022357'},
                                          headers={'accept': 'application/json', 'cache-control': 'no-cache',
                                                   'content-type': 'application/x-www-form-urlencoded'})


def test_refresh_token_fail():
    with patch('coldquanta.qc_client_api.common.auth.okta.okta_api.requests.post') as mock_post:
        mock_post.side_effect = HTTPError()

        okta = OktaAPI()

        mock_refresh_token = "initial_refresh_token"

        with pytest.raises(HTTPError):
            # Call method
            credential_dictionary = okta.refresh_token(mock_refresh_token)

        assert mock_post.called == True


def test_get_service_credentials():
    with patch('coldquanta.qc_client_api.common.auth.okta.okta_api.requests.post') as mock_post:
        # Mock okta response
        mock_okta_response_json = {
            "access_token": "mock_access_token",
        }

        mock_response = MagicMock()

        mock_response.json.return_value = mock_okta_response_json
        mock_post.return_value = mock_response

        mock_client_id = "some_random_string"

        okta = OktaAPI(client_id=mock_client_id)

        mock_client_secret = "client_secret"
        # Call method
        access_token = okta.get_new_service_credentials(client_secret=mock_client_secret)

        assert access_token == "mock_access_token"
        assert mock_post.called == True
        concat_secret = mock_client_id + ":" + "client_secret"
        basic_digest = base64.b64encode(bytes(concat_secret, 'utf-8')).decode("utf-8")
        expected_auth_header = "Basic " + basic_digest

        mock_post.assert_called_once_with('https://dev-528090.okta.com/oauth2/default/v1/token',
                                          allow_redirects=False,
                                          data={'grant_type': 'client_credentials', 'scope': 'machine'},
                                          headers={'accept': 'application/json',
                                                   'cache-control': 'no-cache',
                                                   'content-type': 'application/x-www-form-urlencoded',
                                                   'authorization': expected_auth_header})

        # Check that the basic digest was computed correctly by inverting it
        basic_digest_request = mock_post.call_args[1]["headers"]["authorization"]
        decoded = base64.b64decode(basic_digest_request.replace('Basic ', '')).decode("utf-8")
        assert decoded.split(':')[0] == mock_client_id
        assert decoded.split(':')[1] == 'client_secret'


def test_get_service_credentials_fails():
    with patch('coldquanta.qc_client_api.common.auth.okta.okta_api.requests.post') as mock_post:
        mock_post.side_effect = HTTPError()

        okta = OktaAPI()

        with pytest.raises(HTTPError):
            # Call method
            okta.get_new_service_credentials(client_secret="some_secret")

        assert mock_post.called == True
