# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from coldquanta.qiskit_tools.coldquanta_sim_backend import ColdQuantaSimBackend
from qiskit import Aer, execute, QuantumCircuit, transpile
import math
from qiskit.extensions.standard.cz import CzGate
import pytest


def test_constructor():
    backend = ColdQuantaSimBackend(rows=2, cols=2)


def test_use_backend_noise_free_simulation():
    neutral_atom = ColdQuantaSimBackend(rows=2, cols=2)
    neutral_atom_config = neutral_atom.configuration()
    coupling_map = neutral_atom_config.coupling_map

    circ = QuantumCircuit(4)

    circ.ry(q=0, theta=math.pi / 2)
    circ.cz(0, 1)

    circ.measure_all()

    simulator = Aer.get_backend('qasm_simulator')

    # Execute noisy simulation and get counts
    result = execute(circ,
                     backend=simulator,
                     # basis_gates=neutral_atom_config.basis_gates,
                     coupling_map=coupling_map).result()

    counts_dictionary = result.get_counts()

    assert len(counts_dictionary.keys()) == 2
    assert '0000' in counts_dictionary
    assert '0001' in counts_dictionary


def check_circuit_connectivity(circuit, backend):
    cz_connections = backend.configuration().coupling_map

    circuit_operations = circuit._data
    for circuit_op in circuit_operations:
        if isinstance(circuit_op[0], CzGate):
            qubit_a = circuit_op[1][0].index
            qubit_b = circuit_op[1][1].index

            connection = [qubit_a, qubit_b]

            if connection not in cz_connections:
                raise ValueError(
                    "Invalid cz gate between qubit {} and {} that are not connected".format(qubit_a, qubit_b))


def test_use_backend_noise_free_simulation_invalid_connectivity():
    neutral_atom = ColdQuantaSimBackend(rows=2, cols=2)
    neutral_atom_config = neutral_atom.configuration()
    coupling_map = neutral_atom_config.coupling_map

    circ = QuantumCircuit(4)

    circ.r(q=0, theta=math.pi / 2, phi=math.pi / 4)

    # upper left to lower right connection that does not exist
    circ.cz(0, 3)

    circ.measure_all()

    with pytest.raises(ValueError) as exc:
        neutral_atom.validate_circuit(circ)

    assert exc.value.args[0] == "CZ gate between qubits 0 and 3 is not possible"


def test_use_backend_noise_free_simulation_non_native_operation():
    neutral_atom = ColdQuantaSimBackend(rows=2, cols=2)
    neutral_atom_config = neutral_atom.configuration()
    coupling_map = neutral_atom_config.coupling_map

    circ = QuantumCircuit(4)

    circ.cnot(0, 1)

    circ.measure_all()

    with pytest.raises(ValueError) as exc:
        neutral_atom.validate_circuit(circ)

    assert exc.value.args[
               0] == "Circuit operation cx has no equivalent in the neutral atom gateset ['id', 'cz', 'r', 'rz', 'measure', 'barrier']"
