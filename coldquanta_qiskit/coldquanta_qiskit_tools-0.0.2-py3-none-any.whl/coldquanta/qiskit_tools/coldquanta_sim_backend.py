# Copyright 2020 ColdQuanta Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from qiskit.providers import BaseBackend
from qiskit.providers.models import (BackendStatus, BackendProperties,
                                     BackendConfiguration)
from qiskit.qobj import Qobj
from qiskit import QuantumCircuit
from coldquanta.qc_client_api.protos import qc_client_api_pb2
from coldquanta.qc_client_api.common.mock_qpu_utils import generate_qpu_state
from coldquanta.qc_client_api.common.validate_job_input import is_job_input_valid

from coldquanta.qiskit_tools.qiskit_adapter_utils import qpu_state_to_ibm_config, qiskit_circuit_to_coldquanta_circuit


class ColdQuantaSimBackend(BaseBackend):

    def __init__(self, *, rows:int, cols:int):
        """
        :param rows: integer number of rows in atomic grid
        :param cols: integer numerb of columns in atomic grid
        """

        self._rows = rows
        self._cols = cols

        # Generate a mock qpu state instead of querying the API
        self._coldquanta_qpu_state = generate_qpu_state(rows=self._rows, cols=self._cols, max_shots=10000)

        # Convert to qiskit configuration
        self._configuration = qpu_state_to_ibm_config(self._coldquanta_qpu_state, name="coldquanta_local_sim")

        super().__init__(provider=None, configuration=self._configuration)

    def run(self, qobj: Qobj):
        raise NotImplementedError(
            "This backend is only meant to create mock configuration, then be run using the qasm simulator")

    def validate_circuit(self, circuit:QuantumCircuit) -> None:
        """

        :param circuit: qiskit circuit
        :return:
        """
        # Translate qobj to ColdQuanta protobuf object
        api_circuit = qiskit_circuit_to_coldquanta_circuit(circuit)
        number_shots = 1

        api_job_input_message = qc_client_api_pb2.QPUJobInput(qpu_id=qc_client_api_pb2.QPUId(qpu_id="asdfsdf"),
                                                              circuit=api_circuit,
                                                              shots=number_shots)

        # Validate circuit using ColdQuanta configuration
        is_valid, message = is_job_input_valid(job_input=api_job_input_message, qpu_state=self._coldquanta_qpu_state)

        if not is_valid:
            raise ValueError(message)

    def configuration(self):
        """Return the backend configuration.

        Returns:
            BackendConfiguration: the configuration for the backend.
        """

        # This may be called frequently, use attribute instead requesting
        # the configuration on demand from the coldquanta API

        return self._configuration

    def properties(self):
        """Return the backend properties.

        Returns:
            BackendProperties: the configuration for the backend. If the backend
            does not support properties, it returns ``None``.
        """

        # TODO -> parameterized noise model coming soon

        #properties = BackendProperties(backend_name="coldquanta_local_sim",
        #                               backend_version="1.0.0",
        #                               )

        return None

    def provider(self):
        """Return the backend Provider.

        Returns:
            BaseProvider: the Provider responsible for the backend.
        """
        return self._provider

    def status(self):
        """Return the backend status.

        Returns:
            BackendStatus: the status of the backend.
        """
        return BackendStatus(backend_name="coldquanta_local_sim",
                             backend_version="1.0.0",
                             operational=True,
                             pending_jobs=0,
                             status_msg='')

    def name(self):
        """Return the backend name.

        Returns:
            str: the name of the backend.
        """
        return self._configuration.backend_name
